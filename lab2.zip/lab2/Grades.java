public class Grades{
	public static void main(String[] args){
		//38 back slashes because each "real" backslash needs another one as an escape character
		System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
		System.out.println("==          Student Points          ==");
		System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
		System.out.println();

		System.out.print("Name\t\tLab\tBonus\tTotal\n");
		System.out.print("----\t\t---\t-----\t-----\n");

		System.out.print("Hursh\t\t43\t7\t50\n");
		System.out.print("Sean\t\t49\t0\t49\n");
		System.out.print("Pranav\t\t50\t2\t52\n");
		System.out.print("Rohan\t\t40\t0\t40\n");
		System.out.print("Lebron\t\t47\t3\t50\n");

	}
}