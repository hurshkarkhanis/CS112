public class Robins{
	public static void main(String[] args){
		System.out.println("Ten robins plus " + 13 + " canaries is " + 23 + " birds" );
	}
}