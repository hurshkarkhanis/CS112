Hursh Karkhanis

FINISHED ON MARCH 8 AT 5:29 PM

I am a bit iffy on my shuffle method, but other than that I think everything else works fine